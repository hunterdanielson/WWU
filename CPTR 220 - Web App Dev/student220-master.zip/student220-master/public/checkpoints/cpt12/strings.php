<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.2 Self-Check 6
 *
 * File Name: arthmetic_expressions.php
 * Username:  Danihu
 * Username:  herrde
 * Course:    CPTR 220
 * Date:      10-12-18
 */

 $s = "herrde is the driver, look at his stuff.";

 print $s;