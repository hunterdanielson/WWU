<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.2 Self-Check 5
 *
 * File Name: arthmetic_expressions.php
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 220
 * Date:      ?
 */

$a = 3;
$b = 4;

$c;
