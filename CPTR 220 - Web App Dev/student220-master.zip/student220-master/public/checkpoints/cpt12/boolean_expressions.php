<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.2 Self-Check 7
 *
 * File Name: boolean_expressions.php
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 220
 * Date:      ?
 */

$x = 27;
$y = 1;
$z = 32;
$b = FALSE;
