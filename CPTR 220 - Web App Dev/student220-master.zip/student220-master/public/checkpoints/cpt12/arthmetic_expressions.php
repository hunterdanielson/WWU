<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.2 Self-Check 4
 *
 * File Name: arthmetic_expressions.php
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 220
 * Date:      ?
 */
