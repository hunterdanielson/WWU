    <!-- Menu of Tables -->
    <nav style="text-align: center">
        <a href="table_1.php">x1</a> | 
        <a href="table_2.php">x2</a> | 
        <a href="table_3.php">x3</a> | 
        <a href="table_4.php">x4</a> | 
        <a href="table_5.php">x5</a>
    </nav>
    <hr>