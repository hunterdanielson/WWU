<!DOCTYPE html>
<html lang="en">

<head>
    <title>Multiplication Table For 5</title>
    <meta charset="UTF-8">
</head>

<body>
    <?php include 'table_menu.php'; 
    
    
    include 'functions.php';
    tablemaker(5);

    include 'footer.php'; ?>

</body>

</html>