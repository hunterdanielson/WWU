<footer style="text-align: center">
        <hr>
        <p>
            <!-- Validation Links -->
            <a href="https://validator.w3.org/check/referer">validate HTML</a> | 
            <a href="http://jigsaw.w3.org/css-validator/check/referer">validate CSS</a>
        </p>    
    </footer>