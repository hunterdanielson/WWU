# Checkpoint 4 : Validation
## Setting Up Validation

In this checkpoint you will set up HTML validation and fix the HTML document (**validate.html**):

1. Add a validation link to **validate.html**. Select HTML5 as the standard for validations.
1. Add any missing takes to make the HTML good form.
1. Push your changes to your public (production) VM.
1. Fix any issues reported by the validation website.