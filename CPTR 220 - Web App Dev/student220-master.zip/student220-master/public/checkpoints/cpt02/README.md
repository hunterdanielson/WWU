# Checkpoint 2 : Hello World!

## Create an HTML Hello World!

In this checkpoin you will create an HTML document with the following features:

1. Create an HTML file called **hello_world.html** and fill in the HTML to display "Hello World!".
1. Give the HTML file an appropriate **title**.
1. Embed an **image** of the world into the HTML file. YOu may use the "world.png" file.
1. Create a **level 2 header** that displays "Hello World!".
Make sure to include nescessary attributes.
1. Add a **paragraph** that describes the world.
1. Create a new **level 2 header** for Universities.
1. Under the new header, create a **link** to the Walla Walla University website.
1. Add a **paragraph** that describes where the university is located in the world.
