<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pink Pirates Roster</title>
    <meta charset="UTF-8">
</head>

<body>
    <h1>Pink Pirates Roster</h1>

    <!-- TODO Add Roster Table -->

    <hr>
    <p>
        <a href="https://validator.w3.org/check/referer">validate HTML</a> | 
        <a href="http://jigsaw.w3.org/css-validator/check/referer">validate CSS</a>
    </p>    

</body>

</html>