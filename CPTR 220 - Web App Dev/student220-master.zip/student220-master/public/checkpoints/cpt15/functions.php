<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.4
 *
 * File Name: functions.php
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 220
 * Date:      ?
 */

