# Checkpoint 5 : Basic CSS
## Khan Academy - Introduction to CSS

In this checkpoint you will going through the Khan Academy CSS Basics.

1. Navigate to https://www.khanacademy.org/computing/computer-programming/html-css/intro-to-css/pt/css-basics
1. When your finished, or the class is over, take a screen shot of your progress and save it.
1. Add the image to _cpt05_ folder and push to gitlab.