# Checkpoint 3 : More Tags

## Exploring more tags

In this checkpoint you will expand an HTML document (**example.html**) with the following features:

1. A unorder list with ordered nested lists.
1. Build a table for softball team roster and positions.
1. Quote the WWU statement of excellence.
1. Print an ASCII artwork in HTML.
1. Embed the following video: https://archive.org/download/Mr.RogersTalksAboutConflict1/Mr.%20Rogers%20talks%20about%20conflict%20%281522%29.mp4
