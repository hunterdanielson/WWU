<?php

/*************************************************************************
 *
 * In-Class Checkpoint:  Chapter 5.3
 *
 * File Name: embedded.php
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 220
 * Date:      ?
 */


?><!DOCTYPE html>
<html lang="en">

<head>
    <title>Song Lyrics for "Ten In The Bed"</title>
</head>

<body>
    <h1>"Ten In The Bed" Lyrics</h1>

    <h2>Printed Song Lyrics FROM PHP</h2>

    <h2>Printed Song Lyrics With MINIMAL embedded PHP</h2>

</body>

</html>