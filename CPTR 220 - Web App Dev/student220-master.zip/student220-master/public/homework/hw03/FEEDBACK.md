# Feedback

Date: 10-22-2018

## Coding Substance

* _Thoroughness_: 20 points
* _Correctness_: 20 points
* _Standardization_: 20 points

Missing image of sketch.

## Coding Style

* _Formatting_: 12 points
* _Comments_: 0 points

No comments.
Inconsistent formatting.

## Record Keeping

* _Time Records_: 10 points

**Overall Score**: 82 points
