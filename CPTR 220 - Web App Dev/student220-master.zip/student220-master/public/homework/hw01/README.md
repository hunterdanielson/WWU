# Homework 1: HTML Basics

Your single task for this assignment is to create an HTML document that matches the structure shown in the "example_coding.pdf" PDF file. Please pay attention to the following notes.

* Before you begin this assignment, but after you have viewed the attached document, estimate the time you believe it will take you to complete the assignment.  Then log your time and submit both your initial estimate and the final time that it took.

  Include the estimate in the markdown file called ASSIGNMENT.md.

* View the assignment rubric by going to the syllabus on D2L.

* Be sure to utilize appropriate web standards and validate your HTML. (A validation link must be correct in your submission.)

* Assignment is based on reading from chapter 2.

* **Questions?**  Ask your instructor right away so that you don't waste time going down a dead end.