# Assignment Submission Form
## Walla Walla University -- Department of Computer Science

_Name:_ ?

_Course:_ CPTR220

_Assignment:_ ?

_Date:_ ?

_Estimated:_ ?

_Actual Time:_ ?

---


I hereby certify that the code included in this assignment is ENTIRELY my own original work, with the following exceptions:

* Exception one
* Exception two


I hereby certify that the code has been validate using the following validator.
List validators for CSS, HTML, etc.

* validator URL

---

_Digital Signature:_ ???

(Type name or include signature image)
